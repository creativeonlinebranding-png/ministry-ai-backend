import Groq from "groq-sdk";

const client = new Groq({
  apiKey: process.env.GROQ_API_KEY
});

const headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};

export const handler = async (event, context) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  try {
    const body = JSON.parse(event.body || "{}");
    const prompt = body.prompt;
    const mode = body.mode || "general";

    if (!prompt) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "No prompt provided." })
      };
    }

    let taskDescription = "";

    switch (mode) {
      case "sermon":
        taskDescription =
          "You are a ministry assistant. Build a full sermon with outline, scripture references, key points, illustrations, prayer and closing remarks.";
        break;
      case "prayer":
        taskDescription =
          "You are a ministry assistant. Write a powerful personalised prayer with scripture support.";
        break;
      case "explain":
        taskDescription =
          "You are a Bible explainer. Explain the verse with meaning, context, application and modern relevance.";
        break;
      case "advice":
        taskDescription =
          "You are a ministry coach. Give practical ministry strategies, spiritually aligned guidance and scripture-based support.";
        break;
      case "counsel":
        taskDescription =
          "You are a Christian counsellor. Respond with wisdom, comfort, guidance, scripture and clear next steps.";
        break;
      default:
        taskDescription =
          "You are an AI Ministry Assistant. Help with sermons, prayers, Bible explanations, ministry advice and counselling with scripture where needed.";
    }

    const completion = await client.chat.completions.create({
      model: "llama3-70b-8192",
      messages: [
        {
          role: "system",
          content: taskDescription +
            " Always stay respectful and Christ-centred. Do not claim to replace a real pastor or professional therapist."
        },
        { role: "user", content: prompt }
      ]
    });

    const responseText = completion.choices[0]?.message?.content || "";

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ response: responseText })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: "AI request failed", details: err.message })
    };
  }
};
